
import AsyncStorage from "@react-native-async-storage/async-storage";

const BACKEND_BASE = "http://localhost:5000";

export async function apiFetch(path: string, opts: RequestInit = {}) {
  const token = await AsyncStorage.getItem("CURASCAN_JWT");
  const headers: Record<string, string> = { "Content-Type": "application/json", ...(opts.headers as any || {}) };
  if (token) headers["Authorization"] = `Bearer ${token}`;

  const res = await fetch(`${BACKEND_BASE}${path}`, {
    ...opts,
    headers,
  });

  const text = await res.text();
  try {
    return { status: res.status, ok: res.ok, body: JSON.parse(text || "{}") };
  } catch (e) {
    return { status: res.status, ok: res.ok, body: text };
  }
}
