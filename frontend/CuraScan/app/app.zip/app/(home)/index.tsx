
// app/(home)/index.tsx
// This is the main landing screen after a user signs in. It displays a welcome message,
// the user's email, and a sign-out button. It also provides sign-in/sign-up links for logged-out users.

import { SignedIn, SignedOut, useUser } from '@clerk/clerk-expo';
import { Link } from 'expo-router';
import { Text, View, StyleSheet } from 'react-native';
import SignOutButton from '../components/SignOutButton';
import { colors } from '../theme/colors';

export default function HomeScreen() {
  const { user } = useUser();

  return (
    <View style={styles.container}>
      <SignedIn>
        <Text style={styles.title}>Welcome to CuraScan</Text>
        <Text style={styles.subtitle}>{user?.primaryEmailAddress?.emailAddress}</Text>
        <Text style={styles.tagline}>Your Digital Health Companion.</Text>
        <SignOutButton />
      </SignedIn>
      <SignedOut>
        <Text style={styles.title}>Welcome to CuraScan</Text>
        <View style={styles.linkContainer}>
          <Link href="/(auth)/sign-in" style={styles.link}>Sign In</Link>
          <Link href="/(auth)/sign-up" style={styles.link}>Sign Up</Link>
        </View>
      </SignedOut>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.background,
    padding: 20,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: colors.text,
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 18,
    color: colors.textSecondary,
    marginBottom: 20,
  },
  tagline: {
    fontSize: 16,
    color: colors.textSecondary,
    marginBottom: 40,
  },
  linkContainer: {
    flexDirection: 'row',
    marginTop: 20,
  },
  link: {
    color: colors.primary,
    fontSize: 18,
    marginHorizontal: 10,
  },
});
