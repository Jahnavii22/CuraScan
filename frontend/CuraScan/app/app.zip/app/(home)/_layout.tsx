
// app/(home)/_layout.tsx
// This file defines the stack layout for the home screen area of the app,
// which is accessible after a user is authenticated.

import { Stack } from 'expo-router';
import { colors } from '../theme/colors';

export default function HomeLayout() {
  return (
    <Stack
      screenOptions={{
        headerStyle: { backgroundColor: colors.background },
        headerTintColor: colors.text,
        headerTitleStyle: { fontWeight: 'bold' },
      }}
    />
  );
}
