
import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, Pressable, Alert, Image } from 'react-native';
import { SignedIn, SignedOut, useUser } from '@clerk/clerk-expo';
import { Link, useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import SignOutButton from '../components/SignOutButton';
import { colors, gradientColors } from '../theme/colors';
import { LinearGradient } from 'expo-linear-gradient';
import UploadSheet from '../components/UploadSheet';

export default function HomeScreen() {
  const { user } = useUser();
  const router = useRouter();
  const [sheetMode, setSheetMode] = useState<'closed' | 'pdf' | 'image'>('closed');

  // show popup once user logs in
  useEffect(() => {
    if (user) {
      Alert.alert('Welcome to CuraScan', `Hi ${user.fullName || 'User'}!`);
    }
  }, [user]);

  return (
    <View style={styles.container}>
      <SignedIn>
        {/* Header Section */}
        <LinearGradient colors={gradientColors} style={styles.header}>
          <Pressable onPress={() => router.push('/(home)/edit-profile')}>
            <Image
              source={
                user?.imageUrl
                  ? { uri: user.imageUrl }
                  : require('../../assets/images/CuraScan.png')
              }
              style={styles.avatar}
            />
          </Pressable>
          <Text style={styles.headerText}>Welcome to CuraScan</Text>
          <Ionicons name="notifications-outline" size={24} color="white" />
        </LinearGradient>

        {/* Content Section */}
        <View style={styles.content}>
          <Text style={styles.subtitle}>
            {user?.primaryEmailAddress?.emailAddress}
          </Text>
          <Text style={styles.tagline}>Your AI Blood Report Analyzer</Text>

          <Pressable style={styles.uploadBtn} onPress={() => setSheetMode('pdf')}>
            <Ionicons name="document-text-outline" size={20} color="white" />
            <Text style={styles.uploadText}>Upload PDF</Text>
          </Pressable>

          <Pressable style={styles.uploadBtn} onPress={() => setSheetMode('image')}>
            <Ionicons name="image-outline" size={20} color="white" />
            <Text style={styles.uploadText}>Upload Image</Text>
          </Pressable>

          <View style={styles.signout}>
            <SignOutButton />
          </View>
        </View>

        {/* Upload Options Half-Sheet */}
        <UploadSheet
          {...({
            mode: sheetMode,
            onClose: () => setSheetMode('closed'),
            onPicked: (uri: string, type: string) => {
              console.log('Selected:', uri, type);
              Alert.alert('Upload Successful', `${type.toUpperCase()} selected.`);
              setSheetMode('closed');
            },
          } as any)}
        />
      </SignedIn>

      {/* If not signed in */}
      <SignedOut>
        <Text style={styles.title}>Welcome to CuraScan</Text>
        <View style={styles.linkContainer}>
          <Link href="/(auth)/sign-in" style={styles.link}>
            Sign In
          </Link>
          <Link href="/(auth)/sign-up" style={styles.link}>
            Sign Up
          </Link>
        </View>
      </SignedOut>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    height: 120,
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
  },
  headerText: {
    color: 'white',
    fontSize: 18,
    fontWeight: '700',
  },
  avatar: {
    width: 48,
    height: 48,
    borderRadius: 24,
    borderWidth: 2,
    borderColor: 'white',
  },
  content: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 20,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: colors.text,
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 18,
    color: colors.textSecondary,
    marginTop: 20,
  },
  tagline: {
    fontSize: 16,
    color: colors.textSecondary,
    marginVertical: 30,
  },
  uploadBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.card,
    borderRadius: 12,
    paddingVertical: 14,
    paddingHorizontal: 24,
    marginVertical: 10,
    elevation: 3,
  },
  uploadText: {
    color: colors.text,
    fontWeight: '600',
    fontSize: 16,
    marginLeft: 10,
  },
  signout: {
    marginTop: 30,
  },
  linkContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 20,
  },
  link: {
    color: colors.primary,
    fontSize: 18,
    marginHorizontal: 10,
  },
});
