import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  Pressable,
  StyleSheet,
  Platform,
  Alert,
  ActivityIndicator,
} from "react-native";
import Modal from "react-native-modal";
import * as DocumentPicker from "expo-document-picker";
import * as ImagePicker from "expo-image-picker";
import { Ionicons } from "@expo/vector-icons";
import colors from "../theme/colors";
import { uploadFile, apiFetch } from "../utils/api";
import { useUser } from "@clerk/clerk-expo";

type Props = {
  mode: "closed" | "pdf" | "image";
  onClose: () => void;
  onDone?: (report: any) => void; // returns saved report from backend
};

export default function UploadSheet({ mode, onClose, onDone }: Props) {
  const { user } = useUser();
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (mode !== "closed" && Platform.OS !== "web") {
      (async () => {
        try {
          const cam = await ImagePicker.requestCameraPermissionsAsync();
          const lib = await ImagePicker.requestMediaLibraryPermissionsAsync();
          if (cam.status !== "granted" || lib.status !== "granted") {
            Alert.alert(
              "Permissions required",
              "Please allow camera & media permissions."
            );
          }
        } catch (e) {
          console.warn("Permission request failed", e);
        }
      })();
    }
  }, [mode]);

  const uploadAndProcess = async (
    localUri: string,
    filename: string,
    mimeType: string,
    fileType: "pdf" | "image"
  ) => {
    try {
      if (!localUri) {
        Alert.alert("Error", "Invalid file uri");
        return;
      }

      setLoading(true);
      const clerkUserId = user?.id ?? ""; // Clerk user id (string) - backend accepts this
      const resp = await uploadFile(localUri, filename, mimeType, { clerkUserId });

      if (!resp.ok) {
        console.error("Upload failed:", resp);
        Alert.alert("Upload failed", resp.body?.msg || JSON.stringify(resp.body));
        return;
      }

      const reportId = resp.body?.reportId ?? resp.body?.report?._id;
      if (!reportId) {
        Alert.alert("Upload error", "No report id returned from server.");
        return;
      }

      // call process endpoint to run extractor + ML
      const proc = await apiFetch(`/api/process/${reportId}`, { method: "POST" });
      if (!proc.ok) {
        console.error("Processing failed:", proc);
        Alert.alert("Processing failed", proc.body?.msg || JSON.stringify(proc.body));
        onDone?.(resp.body?.report ?? { id: reportId });
        return;
      }

      // success
      Alert.alert("Done", "File uploaded and processed.");
      onDone?.(proc.body?.report ?? proc.body);
    } catch (err) {
      console.error("uploadAndProcess error:", err);
      Alert.alert("Error", "Upload or processing failed. See console for details.");
    } finally {
      setLoading(false);
      onClose();
    }
  };

  // best-effort name + mime guess
  const guessNameAndMime = (uri: string, defaultName: string) => {
    try {
      const last = uri.split("/").pop() || defaultName;
      const ext = last.includes(".") ? last.split(".").pop()!.toLowerCase() : "";
      let mime = "application/octet-stream";
      if (/(pdf)/i.test(ext)) mime = "application/pdf";
      else if (/(jpe?g|jpg)/i.test(ext)) mime = "image/jpeg";
      else if (/(png)/i.test(ext)) mime = "image/png";
      return { name: last, mime };
    } catch {
      return { name: defaultName, mime: "application/octet-stream" };
    }
  };

  // Document picker (defensive typing)
  const onPickDocument = async () => {
    try {
      const res = (await DocumentPicker.getDocumentAsync({ type: "*/*" })) as any;
      // expo-document-picker may return { type: 'success', uri, name } or { type: 'cancel' } shape
      if (!res) return;
      // older/newer SDKs use res.type === 'success' OR res.cancelled boolean - be defensive
      const succeeded =
        res.type === "success" || (res.uri && !res.cancelled && !res.canceled);
      const uri = res.uri ?? res.uri; // explicit
      const nameFromRes = res.name ?? res.fileName ?? undefined;

      if (!succeeded || !uri) {
        // user cancelled or no uri
        return;
      }

      const { name, mime } = guessNameAndMime(uri, nameFromRes ?? `report-${Date.now()}.pdf`);
      await uploadAndProcess(uri, name, mime, "pdf");
    } catch (err) {
      console.error("pickDocument error:", err);
      Alert.alert("Error", "Unable to pick document.");
    }
  };

  // Image library picker
  const onPickImageLibrary = async () => {
    try {
      const res = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        quality: 0.8,
      });

      // Newer API: { canceled: boolean, assets: [{ uri, ...}] }
      // Older API: { cancelled: boolean, uri }
      const canceled = (res as any).canceled ?? (res as any).cancelled ?? false;
      if (canceled) return;

      const asset = (res as any).assets?.[0] ?? (res as any);
      const uri = asset?.uri;
      if (!uri) {
        Alert.alert("Error", "No image selected.");
        return;
      }

      const { name, mime } = guessNameAndMime(uri, `image-${Date.now()}.jpg`);
      await uploadAndProcess(uri, name, mime, "image");
    } catch (err) {
      console.error("pickImageLibrary error:", err);
      Alert.alert("Error", "Unable to pick image.");
    }
  };

  // Camera
  const onTakePhoto = async () => {
    try {
      const res = await ImagePicker.launchCameraAsync({ quality: 0.8 });
      const canceled = (res as any).canceled ?? (res as any).cancelled ?? false;
      if (canceled) return;

      const asset = (res as any).assets?.[0] ?? (res as any);
      const uri = asset?.uri;
      if (!uri) {
        Alert.alert("Error", "No photo captured.");
        return;
      }

      const { name, mime } = guessNameAndMime(uri, `photo-${Date.now()}.jpg`);
      await uploadAndProcess(uri, name, mime, "image");
    } catch (err) {
      console.error("takePhoto error:", err);
      Alert.alert("Error", "Unable to take photo.");
    }
  };

  return (
    <Modal
      isVisible={mode !== "closed"}
      onBackdropPress={() => {
        if (!loading) onClose();
      }}
      style={styles.modal}
      swipeDirection={["down"]}
      onSwipeComplete={() => {
        if (!loading) onClose();
      }}
      avoidKeyboard
    >
      <View style={styles.sheet}>
        <View style={styles.drag} />
        <Text style={styles.title}>{mode === "pdf" ? "Upload PDF" : "Upload Image"}</Text>

        {loading ? (
          <View style={{ alignItems: "center", marginTop: 20 }}>
            <ActivityIndicator size="large" color={colors.primary} />
            <Text style={{ color: colors.textSecondary, marginTop: 12 }}>
              Uploading & processing...
            </Text>
          </View>
        ) : mode === "pdf" ? (
          <>
            <Pressable style={styles.option} onPress={onPickDocument}>
              <Ionicons name="document-text-outline" size={20} color={colors.primary} />
              <Text style={styles.optionText}>Choose file from device</Text>
            </Pressable>

            <Pressable style={styles.option} onPress={onPickDocument}>
              <Ionicons name="cloud-outline" size={20} color={colors.secondary} />
              <Text style={styles.optionText}>Choose from Drive</Text>
            </Pressable>
          </>
        ) : (
          <>
            <Pressable style={styles.option} onPress={onTakePhoto}>
              <Ionicons name="camera-outline" size={20} color={colors.primary} />
              <Text style={styles.optionText}>Take Photo</Text>
            </Pressable>

            <Pressable style={styles.option} onPress={onPickImageLibrary}>
              <Ionicons name="images-outline" size={20} color={colors.secondary} />
              <Text style={styles.optionText}>Choose from Gallery</Text>
            </Pressable>
          </>
        )}

        <Pressable
          style={styles.cancel}
          onPress={() => {
            if (!loading) onClose();
          }}
        >
          <Text style={styles.cancelText}>Cancel</Text>
        </Pressable>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  modal: { justifyContent: "flex-end", margin: 0 },
  sheet: {
    height: "45%",
    backgroundColor: colors.card,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    padding: 20,
  },
  drag: {
    width: 48,
    height: 4,
    backgroundColor: "#555",
    borderRadius: 4,
    alignSelf: "center",
    marginBottom: 12,
  },
  title: { color: colors.text, fontSize: 18, fontWeight: "700", marginBottom: 14 },
  option: { flexDirection: "row", alignItems: "center", paddingVertical: 12 },
  optionText: { marginLeft: 12, color: colors.text, fontSize: 16 },
  cancel: { marginTop: 20, alignItems: "center" },
  cancelText: { color: colors.textSecondary },
});
