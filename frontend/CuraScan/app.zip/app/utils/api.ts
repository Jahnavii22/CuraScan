// app/utils/api.ts
import AsyncStorage from "@react-native-async-storage/async-storage";

export const BACKEND_BASE = "http://10.0.2.2:5000"; 
// NOTE: on Android emulator use 10.0.2.2 => localhost:5000. 
// On a real device use your machine IP e.g. http://192.168.1.12:5000

export async function apiFetch(path: string, opts: RequestInit = {}) {
  const token = await AsyncStorage.getItem("CURASCAN_JWT");
  const headers: Record<string, string> = { "Content-Type": "application/json", ...(opts.headers as any || {}) };
  if (token) headers["Authorization"] = `Bearer ${token}`;

  const res = await fetch(`${BACKEND_BASE}${path}`, {
    ...opts,
    headers,
  });

  const text = await res.text();
  try {
    return { status: res.status, ok: res.ok, body: JSON.parse(text || "{}") };
  } catch (e) {
    return { status: res.status, ok: res.ok, body: text };
  }
}

/**
 * Upload a file (multipart/form-data)
 * @param uri local uri (file:// or content:// or web blob url)
 * @param name filename to use on server
 * @param mimeType content type (ex: 'application/pdf' or 'image/jpeg')
 * @param extraFields extra form fields (e.g. { clerkUserId })
 */
export async function uploadFile(
  uri: string,
  name: string,
  mimeType: string,
  extraFields: Record<string, string> = {}
) {
  const token = await AsyncStorage.getItem("CURASCAN_JWT");
  const form = new FormData();

  // RN + Expo expects { uri, name, type }
  // For web, a File object would be better but expo document picker returns a blob url handled by fetch automatically.
  form.append("file", { uri, name, type: mimeType } as any);

  // append extra fields (clerkUserId or userId)
  Object.keys(extraFields).forEach((k) => form.append(k, extraFields[k]));

  const headers: Record<string, string> = {};
  if (token) headers["Authorization"] = `Bearer ${token}`;
  // DO NOT set Content-Type; fetch will set multipart boundary automatically
  try {
    const res = await fetch(`${BACKEND_BASE}/api/upload`, {
      method: "POST",
      body: form as any,
      headers,
    });
    const text = await res.text();
    const body = (() => { try { return JSON.parse(text || "{}"); } catch { return text; } })();
    return { status: res.status, ok: res.ok, body };
  } catch (err) {
    console.error("uploadFile error:", err);
    throw err;
  }
}
